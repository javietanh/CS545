package edu.mum.cs.validator;
import java.util.*;

public interface CalculatorValidator {
    List<String> validate(Object object);
}
