Follow on to Lesson 1 # layer Starbucks..
only with MVC 2 Servlet/JSPs "pairs"
 
