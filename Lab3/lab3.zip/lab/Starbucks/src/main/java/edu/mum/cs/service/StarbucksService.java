package edu.mum.cs.service;

import java.util.List;

public interface StarbucksService {
    List<String> getAdvice(String roast);
}
