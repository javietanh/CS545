package edu.mum.cs.domain;

public class Roast {
    private String roast;

    public String getRoast() {
        return roast;
    }

    public void setRoast(String roast) {
        this.roast = roast;
    }
}
