package edu.mum.validator;

import java.util.List;

public interface CalculatorValidator {
    List<String> validate(Object object);
}
